import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random


def load_texture(path):
    image = pygame.image.load(path)
    image = pygame.transform.flip(image, False, True)
    data = pygame.image.tostring(image, 'RGBA')

    texID = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, texID)

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA,
                 image.get_width(), image.get_height(),
                 0, GL_RGBA, GL_UNSIGNED_BYTE, data)

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)

    return texID


def draw_square():
    glBegin(GL_TRIANGLES)

    glTexCoord2f(0, 0); glVertex3f(-1, -1, 0)
    glTexCoord2f(1, 0); glVertex3f(1, -1, 0)
    glTexCoord2f(1, 1); glVertex3f(1, 1, 0)

    glTexCoord2f(0, 0); glVertex3f(-1, -1, 0)
    glTexCoord2f(1, 1); glVertex3f(1, 1, 0)
    glTexCoord2f(0, 1); glVertex3f(-1, 1, 0)

    glEnd()


def draw_white_square(size=0.2):
    glDisable(GL_TEXTURE_2D)
    glColor3f(1.0, 1.0, 1.0)

    glBegin(GL_QUADS)
    glVertex3f(-size, -size, 0)
    glVertex3f( size, -size, 0)
    glVertex3f( size,  size, 0)
    glVertex3f(-size,  size, 0)
    glEnd()

    glColor3f(1.0, 1.0, 1.0)
    glEnable(GL_TEXTURE_2D)


def draw_cube():
    glPushMatrix()
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()

    glPushMatrix()
    glRotatef(90, 0, 1, 0)
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()

    glPushMatrix()
    glRotatef(-90, 1, 0, 0)
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()

    glPushMatrix()
    glRotatef(180, 0, 1, 0)
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()

    glPushMatrix()
    glRotatef(-90, 0, 1, 0)
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()

    glPushMatrix()
    glRotatef(90, 1, 0, 0)
    glTranslatef(0, 0, 1)
    draw_square()
    glPopMatrix()


def draw_pyramid():
    glBegin(GL_TRIANGLES)

    glTexCoord2f(0.5, 1); glVertex3f(0, 1, 0)
    glTexCoord2f(0, 0);   glVertex3f(-1, -1, 1)
    glTexCoord2f(1, 0);   glVertex3f(1, -1, 1)

    glTexCoord2f(0.5, 1); glVertex3f(0, 1, 0)
    glTexCoord2f(0, 0);   glVertex3f(1, -1, 1)
    glTexCoord2f(1, 0);   glVertex3f(1, -1, -1)

    glTexCoord2f(0.5, 1); glVertex3f(0, 1, 0)
    glTexCoord2f(0, 0);   glVertex3f(1, -1, -1)
    glTexCoord2f(1, 0);   glVertex3f(-1, -1, -1)

    glTexCoord2f(0.5, 1); glVertex3f(0, 1, 0)
    glTexCoord2f(0, 0);   glVertex3f(-1, -1, -1)
    glTexCoord2f(1, 0);   glVertex3f(-1, -1, 1)

    glEnd()


def draw_star():
    glBegin(GL_TRIANGLES)

    outer_r = 1.3
    inner_r = 0.5
    points = []

    for i in range(10):
        angle = math.radians(i * 36)
        r = outer_r if i % 2 == 0 else inner_r
        points.append((r * math.cos(angle), r * math.sin(angle)))

    for i in range(10):
        p1 = points[i]
        p2 = points[(i + 1) % 10]

        glTexCoord2f(0.5, 1); glVertex3f(0, 0, 0.6)
        glTexCoord2f(0, 0);   glVertex3f(p1[0], p1[1], 0)
        glTexCoord2f(1, 0);   glVertex3f(p2[0], p2[1], 0)

    for i in range(10):
        p1 = points[i]
        p2 = points[(i + 1) % 10]

        glTexCoord2f(0, 0);   glVertex3f(p1[0], p1[1], 0)
        glTexCoord2f(1, 0);   glVertex3f(p2[0], p2[1], 0)
        glTexCoord2f(0.5, 1); glVertex3f(0, 0, -0.6)

    glEnd()


def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)

    glEnable(GL_DEPTH_TEST)
    glEnable(GL_TEXTURE_2D)

    cube_tex = load_texture("lebron_cube.png")
    pyramid_tex = load_texture("monke_triangle.png")
    star_tex = load_texture("jordan_star.png")

    gluPerspective(45, display[0] / display[1], 0.1, 50.0)
    glTranslatef(0, 0, -14)

    angle = 0

    
    falling_squares = []
    for _ in range(30):
        falling_squares.append({
            "x": random.uniform(-8, 8),
            "y": random.uniform(0, 10),
            "speed": random.uniform(0.02, 0.06)
        })

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        angle += 1

        
        for sq in falling_squares:
            glPushMatrix()
            glTranslatef(sq["x"], sq["y"], -2)
            draw_white_square(0.15)
            glPopMatrix()

            sq["y"] -= sq["speed"]
            if sq["y"] < -6:
                sq["y"] = 10
                sq["x"] = random.uniform(-8, 8)

        
        glPushMatrix()
        glTranslatef(-6, 0, 0)
        glRotatef(angle, 0, 1, 0)
        glBindTexture(GL_TEXTURE_2D, star_tex)
        draw_star()
        glPopMatrix()

        
        glPushMatrix()
        glTranslatef(-2, 0, 0)
        glRotatef(angle, 1, 1, 0)
        glBindTexture(GL_TEXTURE_2D, cube_tex)
        draw_cube()
        glPopMatrix()

        
        glPushMatrix()
        glTranslatef(4, 0, 0)
        glRotatef(angle, 0, 1, 0)
        glBindTexture(GL_TEXTURE_2D, pyramid_tex)
        draw_pyramid()
        glPopMatrix()

        pygame.display.flip()
        pygame.time.wait(10)

    pygame.quit()


main()
