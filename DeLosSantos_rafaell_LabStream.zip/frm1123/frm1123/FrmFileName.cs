﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace frm1123
{
    public partial class FrmFileName : Form
    {

        public static string SetFileName;
        public FrmFileName()
        {
            InitializeComponent();
        }

        private void btn2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("enter a file name!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SetFileName = textBox2.Text + ".txt";
            this.Close();


            Frmregistration frmregistration = new Frmregistration();
            frmregistration.ShowDialog();

        }
    }
}
