﻿namespace frm1123
{
    partial class Frmregistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox11 = new TextBox();
            textBox21 = new TextBox();
            textBox31 = new TextBox();
            textBox41 = new TextBox();
            textBox51 = new TextBox();
            textBox61 = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            button12 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            SuspendLayout();
            // 
            // textBox11
            // 
            textBox11.Location = new Point(153, 66);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(198, 23);
            textBox11.TabIndex = 0;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(153, 128);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(198, 23);
            textBox21.TabIndex = 1;
            // 
            // textBox31
            // 
            textBox31.Location = new Point(153, 205);
            textBox31.Name = "textBox31";
            textBox31.Size = new Size(82, 23);
            textBox31.TabIndex = 2;
            // 
            // textBox41
            // 
            textBox41.Location = new Point(484, 128);
            textBox41.Name = "textBox41";
            textBox41.Size = new Size(168, 23);
            textBox41.TabIndex = 3;
            // 
            // textBox51
            // 
            textBox51.Location = new Point(695, 128);
            textBox51.Name = "textBox51";
            textBox51.Size = new Size(73, 23);
            textBox51.TabIndex = 4;
            // 
            // textBox61
            // 
            textBox61.Location = new Point(621, 287);
            textBox61.Name = "textBox61";
            textBox61.Size = new Size(147, 23);
            textBox61.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(153, 287);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(229, 23);
            dateTimePicker1.TabIndex = 6;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(484, 66);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(284, 23);
            comboBox1.TabIndex = 7;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(615, 205);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(153, 23);
            comboBox2.TabIndex = 8;
            // 
            // button12
            // 
            button12.Location = new Point(410, 368);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 9;
            button12.Text = "Register";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 69);
            label1.Name = "label1";
            label1.Size = new Size(68, 15);
            label1.TabIndex = 10;
            label1.Text = "Student no.";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 136);
            label2.Name = "label2";
            label2.Size = new Size(63, 15);
            label2.TabIndex = 11;
            label2.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 213);
            label3.Name = "label3";
            label3.Size = new Size(28, 15);
            label3.TabIndex = 12;
            label3.Text = "Age";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(47, 295);
            label4.Name = "label4";
            label4.Size = new Size(51, 15);
            label4.TabIndex = 13;
            label4.Text = "Birthday";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(398, 69);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 14;
            label5.Text = "Program";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(398, 136);
            label6.Name = "label6";
            label6.Size = new Size(64, 15);
            label6.TabIndex = 15;
            label6.Text = "First Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(658, 131);
            label7.Name = "label7";
            label7.Size = new Size(21, 15);
            label7.TabIndex = 16;
            label7.Text = "Mi";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(513, 213);
            label8.Name = "label8";
            label8.Size = new Size(45, 15);
            label8.TabIndex = 17;
            label8.Text = "Gender";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(513, 290);
            label9.Name = "label9";
            label9.Size = new Size(69, 15);
            label9.TabIndex = 18;
            label9.Text = "Contact no.";
            // 
            // Frmregistration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(926, 450);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button12);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(textBox61);
            Controls.Add(textBox51);
            Controls.Add(textBox41);
            Controls.Add(textBox31);
            Controls.Add(textBox21);
            Controls.Add(textBox11);
            Name = "Frmregistration";
            Text = "Frmregistration";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox11;
        private TextBox textBox21;
        private TextBox textBox31;
        private TextBox textBox41;
        private TextBox textBox51;
        private TextBox textBox61;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Button button12;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
    }
}