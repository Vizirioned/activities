﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm1123
{
    public partial class Frmregistration : Form
    {
        public Frmregistration()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "BSIT", "BS Computer Science", "BSTM", "BSCM" });
            comboBox2.Items.AddRange(new string[] { "Male", "Female" });


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            string studentNumber = textBox11.Text.Trim();
            string lastName = textBox21.Text.Trim();
            string firstName = textBox41.Text.Trim();
            string middleInitial = textBox51.Text.Trim();
            string course = comboBox1.Text.Trim();
            string gender = comboBox2.Text.Trim();
            string age = textBox31.Text.Trim();
            string birthday = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string contactNumber = textBox61.Text.Trim();


            if (string.IsNullOrWhiteSpace(studentNumber) || string.IsNullOrWhiteSpace(lastName) ||
                string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(middleInitial) ||
                string.IsNullOrWhiteSpace(course) || string.IsNullOrWhiteSpace(gender) ||
                string.IsNullOrWhiteSpace(age) || string.IsNullOrWhiteSpace(contactNumber))
            {
                MessageBox.Show("Please fill out all fields!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(age, out int parsedAge) || parsedAge <= 0)
            {
                MessageBox.Show("Please enter a valid age!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!long.TryParse(contactNumber, out _))
            {
                MessageBox.Show("Please enter a valid contact number!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            string fullName = $"{lastName}, {firstName}, {middleInitial}.";


            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string fileName = Path.Combine(docPath, $"{studentNumber}.txt");


            string[] fileContent = {
    $"Student Number: {studentNumber}",
    $"Full Name: {fullName}",
    $"Program: {course}",
    $"Gender: {gender}",
    $"Age: {age}",
    $"Birthday: {birthday}",
    $"Contact Number: {contactNumber}"
};


            try
            {
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    foreach (string line in fileContent)
                    {
                        writer.WriteLine(line);
                    }
                }

                MessageBox.Show($"Registration saved successfully in file:\n{fileName}",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                System.Diagnostics.Process.Start("notepad.exe", fileName);


                textBox11.Clear();
                textBox21.Clear();
                textBox31.Clear();
                textBox41.Clear();
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                textBox51.Clear();
                dateTimePicker1.Value = DateTime.Today;
                textBox61.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving the file:\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
